import datetime
from telegram import ChatPermissions
from telegram import Update

# Обработка команды "rek"
async def handle_rek(update: Update, context, has_permission):
    if update.message.reply_to_message and has_permission(update.message.from_user.id, "rek"):
        mute_time = datetime.timedelta(days=5)
        until_date = datetime.datetime.now() + mute_time
        # Преобразуем until_date в формат, который Telegram понимает
        await context.bot.restrict_chat_member(
            chat_id=update.message.chat_id,
            user_id=update.message.reply_to_message.from_user.id,
            permissions=ChatPermissions(can_send_messages=False),
            until_date=until_date
        )
        await context.bot.delete_message(
            chat_id=update.message.chat_id,
            message_id=update.message.reply_to_message.message_id
        )
        await context.bot.send_message(
            chat_id=update.message.chat_id, 
            text=f"Лах размутиться в {until_date}!"
        )

# Обработка команды "18p"
async def handle_18p(update: Update, context, has_permission):
    if update.message.reply_to_message and has_permission(update.message.from_user.id, "18p"):
        mute_time = datetime.timedelta(hours=5)
        until_date = datetime.datetime.now() + mute_time
        # Преобразуем until_date в формат, который Telegram понимает
        await context.bot.restrict_chat_member(
            chat_id=update.message.chat_id,
            user_id=update.message.reply_to_message.from_user.id,
            permissions=ChatPermissions(can_send_messages=False),
            until_date=until_date
        )
        await context.bot.delete_message(
            chat_id=update.message.chat_id,
            message_id=update.message.reply_to_message.message_id
        )
        await context.bot.send_message(
            chat_id=update.message.chat_id, 
            text=f"Лах размутиться в {until_date}!"
        )

# Обработка команды "rod"
async def handle_rod(update: Update, context, has_permission):
    if update.message.reply_to_message and has_permission(update.message.from_user.id, "rod"):
        mute_time = datetime.timedelta(days=1)
        until_date = datetime.datetime.now() + mute_time
        # Преобразуем until_date в формат, который Telegram понимает
        await context.bot.restrict_chat_member(
            chat_id=update.message.chat_id,
            user_id=update.message.reply_to_message.from_user.id,
            permissions=ChatPermissions(can_send_messages=False),
            until_date=until_date
        )
        await context.bot.delete_message(
            chat_id=update.message.chat_id,
            message_id=update.message.reply_to_message.message_id
        )
        await context.bot.send_message(
            chat_id=update.message.chat_id, 
            text=f"Лах размутиться в {until_date}!"
        )