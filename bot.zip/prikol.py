import random
from telegram import Update
from telegram.ext import ContextTypes

# Функция для обработки команды "выебать"
async def handle_vyebat_command(update: Update, context, user_data):
    from_user_id = update.message.from_user.id  # ID того, кто отправил команду
    to_user_id = update.message.reply_to_message.from_user.id  # ID того, кому направлена команда

    from_rank = user_data.get(from_user_id, 0)  # Ранг того, кто отправил команду
    to_rank = user_data.get(to_user_id, 0)  # Ранг того, кому команда направлена

    # Получаем информацию о пользователе, на кого была отправлена команда
    to_user_info = await context.bot.get_chat_member(update.message.chat_id, to_user_id)
    to_username = to_user_info.user.username if to_user_info.user.username else "Неизвестный"
    
    # Получаем информацию о пользователе, который отправил команду (для ответа ему)
    from_user_info = await context.bot.get_chat_member(update.message.chat_id, from_user_id)
    from_username = from_user_info.user.username if from_user_info.user.username else "Неизвестный"

    # Добавляем символ @ перед username, если он существует
    if to_username != "Неизвестный":
        to_username = f"@{to_username}"

    # Добавляем символ @ для пользователя, который отправил команду
    if from_username != "Неизвестный":
        from_username = f"@{from_username}"

    # Логика для обработки рангов
    if from_rank in [1, 2] and to_rank == 3:
        # Если 1-й или 2-й ранг пытается "выебать" 3-й ранг, бот отвечает реплаем отправителю
        response = f"{from_username}, саси хахал"
        # Ответить реплаем на сообщение отправителя команды
        await context.bot.send_message(
            chat_id=update.message.chat_id,
            text=response,
            reply_to_message_id=update.message.message_id  # Ответ на команду отправителя
        )
    elif from_rank >= 1:
        # Если 1-й или 2-й ранг использует команду "выебать" не против 3-го ранга
        response = f"{from_username} выебал лаха {to_username}"
        # Ответ на сообщение, на которое была использована команда
        await context.bot.send_message(
            chat_id=update.message.chat_id,
            text=response,
            reply_to_message_id=update.message.reply_to_message.message_id  # Ответ на сообщение жертвы
        )
    else:
        # Если у пользователя недостаточно прав
        response = "У вас недостаточно прав, чтобы это сделать."
        # Ответ на команду отправителя
        await context.bot.send_message(
            chat_id=update.message.chat_id,
            text=response,
            reply_to_message_id=update.message.message_id  # Ответ на команду отправителя
        )

# Функция для обработки команды "troll"
async def handle_troll(update: Update, context, has_permission):
    # Список URL с тролл-картинками
    troll_images = [
        "https://images.app.goo.gl/uQEvGrT33gTwLjAy8",  # Замените на реальные URL
        "https://images.app.goo.gl/Kfg83ySnXkbYaMWa9",
        "https://images.app.goo.gl/nsFZUsTAWDFFtRYR7",
        "https://images.app.goo.gl/oQcKiAVe4ZftT1TL6",
        "https://images.app.goo.gl/pN9gtFqGPTgV8r7i7",
        "https://images.app.goo.gl/z9eqUYGK79MnTybp9",
        "https://images.app.goo.gl/koqJCopCnxGoRPNE7"
    ]

    # Случайный выбор картинки из списка
    troll_image_url = random.choice(troll_images)

    if has_permission(update.message.from_user.id, "troll"):
        if update.message.reply_to_message:  # Если вы ответили на сообщение
            # Удаление вашего сообщения с командой "тролл"
            await context.bot.delete_message(
                chat_id=update.message.chat_id,
                message_id=update.message.message_id
            )
            # Отправка случайной картинки в ответ на сообщение, на которое вы ответили
            await context.bot.send_photo(
                chat_id=update.message.chat_id,
                photo=troll_image_url,
                reply_to_message_id=update.message.reply_to_message.message_id
            )
        else:  # Если вы не ответили на сообщение
            # Отправка случайной картинки в общий чат
            await context.bot.send_photo(
                chat_id=update.message.chat_id,
                photo=troll_image_url
            )