import datetime
import json
import os
import random
from telegram import Update, ChatPermissions
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters
import prikol  # Импортируем prikol.py для обработки команды выебать
import mut  # Импортируем новый файл mut.py для обработки мут-команд

YOUR_USER_ID = 5377960160  # Ваш ID
BOT_TOKEN = "6818744033:AAEhsPWwOhMWqht7kxc2ONl-iF7x20zO_mA"  # Токен вашего бота
FILE_NAME = "user_data.txt"  # Имя файла для хранения ID и рангов

# Функция для чтения ID и рангов из файла
def load_user_data():
    if os.path.exists(FILE_NAME):
        with open(FILE_NAME, "r") as file:
            data = {}
            for line in file:
                user_id, rank = line.strip().split(',')
                data[int(user_id)] = int(rank)
            return data
    return {}

# Функция для сохранения ID и рангов в файл
def save_user_data(user_data):
    with open(FILE_NAME, "w") as file:
        for user_id, rank in user_data.items():
            file.write(f"{user_id},{rank}\n")

# Загружаем данные из файла при запуске
user_data = load_user_data()

# Проверка ранга пользователя для выполнения команд
def has_permission(user_id, command):
    rank = user_data.get(user_id, 0)
    if command == "troll" and rank >= 1:
        return True
    elif command in ["rek", "rod", "18p"] and rank >= 2:
        return True
    elif command in ["add", "remove"] and rank == 3:
        return True
    elif command == "list" and rank >= 1:
        return True
    return False



# Обработка команды "add" для добавления нового ID
async def handle_add(update: Update, context):
    if has_permission(update.message.from_user.id, "add"):
        try:
            user_id = int(context.args[0])  # ID пользователя
            rank = int(context.args[1])  # Ранг пользователя
            if rank in [1, 2, 3]:
                user_data[user_id] = rank
                save_user_data(user_data)  # Сохранение данных в файл
                await context.bot.send_message(
                    chat_id=update.message.chat_id,
                    text=f"Добавлен пользователь с ID {user_id} и рангом {rank}."
                )
            else:
                await context.bot.send_message(
                    chat_id=update.message.chat_id,
                    text="Ошибка! Ранг должен быть 1, 2 или 3."
                )
        except (IndexError, ValueError):
            await context.bot.send_message(
                chat_id=update.message.chat_id,
                text="Ошибка! Укажите ID и ранг в формате: /add <ID> <ранг>."
            )

# Обработка команды "remove" для удаления ID
async def handle_remove(update: Update, context):
    if has_permission(update.message.from_user.id, "remove"):
        try:
            user_id = int(context.args[0])  # ID пользователя
            if user_id in user_data:
                del user_data[user_id]  # Удаление пользователя из словаря
                save_user_data(user_data)  # Сохранение изменений в файл
                await context.bot.send_message(
                    chat_id=update.message.chat_id,
                    text=f"Пользователь с ID {user_id} удален."
                )
            else:
                await context.bot.send_message(
                    chat_id=update.message.chat_id,
                    text=f"Ошибка! Пользователь с ID {user_id} не найден."
                )
        except (IndexError, ValueError):
            await context.bot.send_message(
                chat_id=update.message.chat_id,
                text="Ошибка! Укажите ID в формате: /remove <ID>."
            )

# Обработчик команды "show" для вывода всех ID, рангов и пользователей
async def handle_show(update: Update, context):
    if update.message.from_user.id == YOUR_USER_ID or has_permission(update.message.from_user.id, "list"):
        user_data = load_user_data()  # Загружаем данные из файла
        if user_data:
            response = "Список пользователей:\n"
            for user_id, rank in user_data.items():
                try:
                    user_info = await context.bot.get_chat_member(update.message.chat_id, user_id)
                    username = user_info.user.username if user_info.user.username else "Неизвестный"
                    # Убираем символ @, если он есть в username
                    username = username.lstrip('@')  # Убираем символ "@" из начала имени
                    response += f"ID: {user_id}, Ранг: {rank}, Пользователь: {username}\n"
                except Exception as e:
                    print(f"Не удалось получить информацию для пользователя с ID {user_id}: {e}")

            await context.bot.send_message(
                chat_id=update.message.chat_id,
                text=response
            )
        else:
            await context.bot.send_message(
                chat_id=update.message.chat_id,
                text="Список пользователей пуст."
            )
    else:
        await context.bot.send_message(
            chat_id=update.message.chat_id,
            text="У вас нет прав для просмотра списка пользователей."
        )

# Проверка на команду "выебать" и вызов prikol.py
async def handle_vyebat(update: Update, context):
    if update.message.reply_to_message:
        await prikol.handle_vyebat_command(update, context, user_data)  # Передаем обработку в prikol.py

# Обработка команды "list" для вывода списка команд
async def handle_list(update: Update, context):
    if has_permission(update.message.from_user.id, "list"):
        commands = """
        Список команд:
        rek - замутить на 5 дней (доступно с ранга 2)
        18p - замутить на 5 часов (доступно с ранга 2)
        rod - замутить на 1 день (доступно с ранга 2)
        тролл - отправить тролл-картинку (доступно с ранга 1)
        /add <ID> <ранг> - добавить нового пользователя (доступно с ранга 3)
        /remove <ID> - удалить пользователя (доступно с ранга 3)
        /show - посмотреть у кого есть доступ (с 1 ранга)
        выебать - тут все понятно (с 1 ранга)
        """
        await context.bot.send_message(
            chat_id=update.message.chat_id,
            text=commands
        )

# Обработчик ошибок
async def error_handler(update: Update, context):
    print(f"Произошла ошибка: {context.error}")

# Обработчик команды "rek" и другие команды в файле mut.py
async def handle_rek(update: Update, context):
    await mut.handle_rek(update, context, has_permission)

async def handle_18p(update: Update, context):
    await mut.handle_18p(update, context, has_permission)

async def handle_rod(update: Update, context):
    await mut.handle_rod(update, context, has_permission)
    
# Остальные команды ...

if __name__ == '__main__':
    application = ApplicationBuilder().token(BOT_TOKEN).build()

    # Обработчики команд
    application.add_handler(CommandHandler("show", handle_show))
    application.add_handler(MessageHandler(filters.TEXT & filters.Regex('(?i)rek'), handle_rek))
    application.add_handler(MessageHandler(filters.TEXT & filters.Regex('(?i)18p'), handle_18p))
    application.add_handler(MessageHandler(filters.TEXT & filters.Regex('(?i)rod'), handle_rod))
    # Добавляем обработчик команды "тролл"
    application.add_handler(MessageHandler(filters.TEXT & filters.Regex('(?i)тролл'), lambda u, c: prikol.handle_troll(u, c, has_permission)))
    application.add_handler(CommandHandler("add", handle_add))  # Команда для добавления нового ID
    application.add_handler(CommandHandler("remove", handle_remove))  # Команда для удаления ID
    application.add_handler(MessageHandler(filters.TEXT & filters.Regex('(?i)выебать'), handle_vyebat))  # Обработчик для команды "выебать"
    application.add_handler(MessageHandler(filters.TEXT & filters.Regex('(?i)list'), handle_list))  # Команда для вывода списка команд, текст без / и с проверкой регистра

    # Обработчик ошибок
    application.add_error_handler(error_handler)

    print("Бот запущен!")
    application.run_polling()